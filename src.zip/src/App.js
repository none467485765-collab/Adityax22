export default function FuturisticSchoolWebsite() {
  const stats = [
    {
      title: '1500+ Students',
      desc: 'Learning and growing together',
      icon: '👨‍🎓',
    },
    {
      title: 'Experienced Faculty',
      desc: 'Dedicated educators for bright futures',
      icon: '📘',
    },
    {
      title: 'Holistic Education',
      desc: 'Academics, values and all-round development',
      icon: '🏆',
    },
    {
      title: 'Focus On Excellence',
      desc: 'Inspiring students to achieve their best',
      icon: '⭐',
    },
  ];

  const campusImages = [
    '/campus1.jpg',
    '/campus2.jpg',
    '/campus3.jpg',
    '/campus4.jpg',
    '/chairman.jpg',
  ];

  return (
    <div className="bg-[#f5f5f5] text-black min-h-screen">
      {/* Top Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-red-900 text-white flex items-center justify-center font-bold text-xl">
              S
            </div>

            <div>
              <h1 className="text-2xl md:text-3xl font-black text-[#7b0000] leading-tight">
                SHRI SHANKAR MUMUKSHU VIDYAPEETH
              </h1>

              <p className="text-sm text-gray-600 mt-1">
                Affiliated to C.B.S.E., New Delhi
              </p>
            </div>
          </div>

          <div className="text-sm text-gray-700 space-y-1 text-center md:text-right">
            <p>(05842) 240107</p>
            <p>ssmv8967spn@rediffmail.com</p>
          </div>
        </div>
      </div>

      {/* Navbar */}
      <nav className="bg-[#7b0000] text-white sticky top-0 z-50 shadow-lg">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-wrap items-center justify-center gap-8 text-sm font-semibold tracking-wide">
          <a href="#" className="hover:text-yellow-200 transition">HOME</a>
          <a href="#about" className="hover:text-yellow-200 transition">ABOUT US</a>
          <a href="#academics" className="hover:text-yellow-200 transition">ACADEMICS</a>
          <a href="#campus" className="hover:text-yellow-200 transition">GALLERY</a>
          <a href="#contact" className="hover:text-yellow-200 transition">CONTACT US</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative h-[85vh] overflow-hidden">
        <img
          src="/campus2.jpg"
          alt="School Campus"
          className="absolute inset-0 w-full h-full object-cover"
        />

        <div className="absolute inset-0 bg-black/45" />

        <div className="relative z-10 h-full flex items-center">
          <div className="max-w-7xl mx-auto px-6 w-full">
            <div className="max-w-2xl text-white">
              <h2 className="text-5xl md:text-7xl font-black leading-tight uppercase">
                Nurturing Minds,
                <br />
                Building Futures
              </h2>

              <p className="mt-6 text-xl text-gray-200 leading-relaxed">
                Where Values Meet Excellence
              </p>

              <button className="mt-10 px-8 py-4 bg-white text-[#7b0000] font-bold rounded-md hover:bg-gray-100 transition">
                Discover More
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid md:grid-cols-4 gap-8">
          {stats.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-md border border-gray-200 p-8 text-center hover:-translate-y-2 transition duration-300"
            >
              <div className="w-16 h-16 mx-auto rounded-full bg-[#7b0000] text-white flex items-center justify-center text-2xl mb-6">
                {item.icon}
              </div>

              <h3 className="text-2xl font-black text-[#7b0000] leading-tight">
                {item.title}
              </h3>

              <p className="mt-4 text-gray-600 leading-relaxed text-sm">
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* About */}
      <section id="about" className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-2 gap-14 items-center">
          <div>
            <p className="text-[#7b0000] font-bold uppercase tracking-[0.2em] text-sm mb-4">
              About Us
            </p>

            <h2 className="text-5xl font-black leading-tight text-black">
              Shri Shankar
              <br />
              Mumukshu Vidyapeeth
            </h2>

            <p className="mt-8 text-gray-700 text-lg leading-relaxed">
              Established with a vision to provide quality education rooted in
              Indian values, Shri Shankar Mumukshu Vidyapeeth aims at the
              holistic development of students and prepares them to become
              responsible citizens of tomorrow.
            </p>
          </div>

          <div>
            <img
              src="/campus2.jpg"
              alt="Campus"
              className="rounded-2xl shadow-2xl border-4 border-white"
            />
          </div>
        </div>
      </section>

      {/* Campus Gallery */}
      <section id="campus" className="py-20 bg-white border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-14">
            <p className="text-[#7b0000] font-bold uppercase tracking-[0.2em] text-sm mb-4">
              Our Campus
            </p>

            <h2 className="text-5xl font-black">Campus Gallery</h2>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {campusImages.map((image, index) => (
              <div
                key={index}
                className="bg-[#fafafa] rounded-xl overflow-hidden shadow-md border border-gray-200"
              >
                <img
                  src={image}
                  alt="Campus"
                  className="h-[220px] w-full object-cover"
                />

                <div className="p-4 text-center font-semibold text-[#7b0000]">
                  {index === 0 && 'Main Building'}
                  {index === 1 && 'Academic Block'}
                  {index === 2 && 'Campus View'}
                  {index === 3 && 'Play Ground'}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Chairman Section */}
      <section className="py-24 bg-[#f8f4f1] border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="absolute inset-0 bg-[#7b0000]/10 blur-3xl rounded-full" />

            <img
              src="/chairman.jpg"
              alt="Swami Chinmiyanand"
              className="relative rounded-3xl shadow-2xl border-4 border-white w-full max-w-md mx-auto"
            />
          </div>

          <div>
            <p className="text-[#7b0000] font-bold uppercase tracking-[0.2em] text-sm mb-4">
              Chairman's Message
            </p>

            <h2 className="text-5xl font-black leading-tight text-black">
              Swami Chinmiyanand
            </h2>

            <p className="mt-8 text-gray-700 text-lg leading-relaxed italic">
              “Education is not only about academic excellence, but also about
              shaping character, discipline, and values that guide students
              throughout life.”
            </p>
          </div>
        </div>
      </section>

      {/* Secretary Section */}
      <section className="py-24 bg-white border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-[#7b0000] font-bold uppercase tracking-[0.2em] text-sm mb-4">
              Secretary's Message
            </p>

            <h2 className="text-5xl font-black leading-tight text-black">
              Ashok Agarwal
            </h2>

            <p className="mt-8 text-gray-700 text-lg leading-relaxed">
              Education is a source of complete living in the tough
              materialistic world in which people are fighting for existence.
            </p>

            <p className="mt-6 text-gray-700 text-lg leading-relaxed">
              But truly speaking, it is life itself building a full-fledged
              unique personality with physical, mental and moral developments.
            </p>
          </div>

          <div className="bg-[#7b0000]/5 rounded-[40px] p-10 border border-gray-200 shadow-xl">
            <div className="space-y-8">
              <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <h3 className="text-2xl font-bold text-[#7b0000] mb-3">
                  Physical Development
                </h3>

                <p className="text-gray-600 leading-relaxed">
                  Encouraging fitness, discipline and healthy lifestyles.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
        {/* Principal Section */}
<section className="py-24 bg-white border-y border-gray-200">
  <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">

    {/* Principal Image */}
    <div className="relative">
      <div className="absolute inset-0 bg-[#7b0000]/10 blur-3xl rounded-full" />

      <img
        src="/principal.jpg"
        alt="Principal"
        className="relative rounded-3xl shadow-2xl border-4 border-white w-full max-w-md mx-auto"
      />
    </div>

    {/* Principal Text */}
    <div>
      <p className="text-[#7b0000] font-bold uppercase tracking-[0.2em] text-sm mb-4">
        Principal's Message
      </p>

      <h2 className="text-5xl font-black leading-tight text-black">
        Meghna Mehndiratta
      </h2>

      <p className="mt-8 text-gray-700 text-lg leading-relaxed italic">
        “Education is the foundation upon which young minds discover their
        potential, build confidence, and shape a brighter future for society.”
      </p>

      <p className="mt-6 text-gray-700 text-lg leading-relaxed">
        At Shri Shankar Mumukshu Vidyapeeth, we are committed to creating an
        environment where students are encouraged to dream big, think
        creatively, and achieve excellence in every sphere of life.
      </p>

      <p className="mt-6 text-gray-700 text-lg leading-relaxed">
        Our goal is not only academic success, but also the development of
        discipline, moral values, leadership qualities, and compassion that
        prepare students to face the challenges of tomorrow with confidence
        and integrity.
      </p>

      <p className="mt-6 text-gray-700 text-lg leading-relaxed">
        Together with dedicated teachers and supportive parents, we strive to
        nurture responsible citizens and lifelong learners who will make a
        positive impact on the world.
      </p>
    </div>

  </div>
</section>

      {/* Why Choose */}
      <section id="academics" className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-14">
          <p className="text-[#7b0000] font-bold uppercase tracking-[0.2em] text-sm mb-4">
            Why Choose SSMV?
          </p>

          <h2 className="text-5xl font-black">Education With Values</h2>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-[#7b0000] text-white mt-10">
        <div className="max-w-7xl mx-auto px-6 py-16 grid md:grid-cols-4 gap-12">
          <div>
            <h3 className="text-2xl font-black mb-5">ABOUT SSMV</h3>

            <p className="text-gray-200 leading-relaxed">
              Shri Shankar Mumukshu Vidyapeeth is committed to providing
              quality education with strong moral values and discipline.
            </p>
          </div>
        </div>

        <div className="border-t border-white/20 py-6 text-center text-sm text-gray-200 px-6">
          <p>© 2025 Shri Shankar Mumukshu Vidyapeeth. All Rights Reserved.</p>

          <p className="mt-3 font-semibold tracking-wide">
            Designed & Updated by ADITYA ✨✨
          </p>
        </div>
      </footer>
    </div>
  );
}